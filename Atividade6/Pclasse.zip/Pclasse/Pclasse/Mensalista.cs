﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasse
{
    internal class Mensalista : Empregado
    {
        public double SalarioMensal {  get; set; }

        public static String Empresa = "Tesla";
        public const String Filial = "Filial Brasil";

        public Mensalista(int matricula, string NomeEmpregado, DateTime DataEntregaEmpresa,
            double SalarioMensal)
        {
            this.NomeEmpregado = NomeEmpregado;
            this.Matricula = matricula;
            this.DataEntradaEmpresa = DataEntregaEmpresa;
            this.SalarioMensal = SalarioMensal;
        }

        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é Mensalista");
        }

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }
    }
}
