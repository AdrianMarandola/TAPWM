var texto = "Observe que essa Mensagem vem do Módulo";
module.exports = texto;
//var express = require('express');